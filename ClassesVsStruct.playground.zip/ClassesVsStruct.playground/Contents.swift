
class MacBook {
    
    var year : Int
    var color: String
    
    init (year: Int, color: String){
        self.year = year
        self.color = color
    }
}


let myMacBook = MacBook(year: 2016, color: "Space Gray")
let stolenMacBook = myMacBook

stolenMacBook.color = "yellow"

print(myMacBook.color) // reference type

// classes - inheritance
// struct - no inheritance 

// no reqmnt of initializer in struct
struct Instrument {
    var number : Int
    var color : String
}

let myInstrument = Instrument(number: 1, color: "Brown")
var stolenmyInstrument = myInstrument

stolenmyInstrument.color = "black"

print(stolenmyInstrument.color) // value type
